# WPF C#–a simple racing game in visual studio
In this project, I will create a top-down racing game in Visual Studio using WPF and C#. In the game, you will drive the player's yellow car and dodge other cars on the road by turning left or right. You can also gather a star in the game to gain temporary invincibility. When you acquire the star, you will be immune to all other traffic while in power mode. WPF components and C# scripts will be used to create this game.

